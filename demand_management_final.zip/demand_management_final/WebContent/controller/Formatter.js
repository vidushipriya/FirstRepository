sap.ui.define(function() {
	"use strict";
 
	var Formatter = {
 
		ReqState :  function (fValue) {
				 if (fValue == "New") {
					return "Warning";
				}  else if(fValue == "Drafts") {
					return "Error";
				}else {
					return "Success";
				}
			}
	};
 
	return Formatter;
 
}, /* bExport= */ true);