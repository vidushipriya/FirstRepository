
sap.ui.define([
		'jquery.sap.global',
		'sap/m/MessageToast',
		'./Formatter',
		'sap/ui/core/mvc/Controller',
		'sap/ui/model/json/JSONModel'
	], function(jQuery, MessageToast, Formatter, Controller, JSONModel) {
	"use strict";
 
	var PageController = Controller.extend("SAP.DemandMgmt.controller.master_admin", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf controller.master_admin
*/
		onInit: function(){
			this.getSplitAppObj().setHomeIcon({
				'phone':'phone-icon.png',
				'tablet':'tablet-icon.png',
				'icon':'desktop.ico'
			});
			
			this.getSplitAppObj().toDetail(this.createId("help_text_page"));
			
			/*var oControlId = ["purposeId","TransitionId","ExpectationId","VolumeId","Milestoneid"]
            for(var i=0; i<oControlId.length;i++){
                         this.getView().byId(oControlId[i]).setEnabled(false);
            }*/
            this.getView().byId("ApplyChangesId").setVisible(false);
            	
            this.getSplitAppObj().setMode("HideMode");
            
            var oData = {
                    RS1: [0,100],
                    RS2: [-50,50],
                    RS3: [20,80],
                    RS4: [-500,500],
                    RS5: [0, 500]
                };

                var oModel =  new JSONModel(oData);
                this.getView().setModel(oModel);
            
			
		},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf controller.master_admin
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf controller.master_admin
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf controller.master_admin
*/
//	onExit: function() {
//
//	}
		onselectdesc:function(oeventpass){
			if(oeventpass.getParameter("selectedItem").getKey() == "01"){
				this.getView().byId("purposeId").setValue("Enter clear purpose for raising DFCR");
			}
		},
	 onPressBack : function(oEvent){
	        var router = sap.ui.core.UIComponent.getRouterFor(this);
	        router.navTo("LaunchPad",{
	               from: "create_request"
	               
	        });
	 },
	 
	 OnPressEditHelpText:function(){
        /* var oControlId = ["purposeId","TransitionId","ExpectationId","VolumeId","Milestoneid"]
                     for(var i=0; i<oControlId.length;i++){
                                  this.getView().byId(oControlId[i]).setEnabled(true);
                     }*/
		 this.getView().byId("purposeId").setEnabled(true);
         this.getView().byId("EditHelpTextId").setVisible(false); 
         this.getView().byId("ApplyChangesId").setVisible(true); 
       },
       OnPressApplyChanges:function(){
        /* var oControlId = ["purposeId","TransitionId","ExpectationId","VolumeId","Milestoneid"]
                     for(var i=0; i<oControlId.length;i++){
                                  this.getView().byId(oControlId[i]).setEnabled(false);
                     }*/
         this.getView().byId("EditHelpTextId").setVisible(true); 
         this.getView().byId("ApplyChangesId").setVisible(false); 
         this.getView().byId("purposeId").setEnabled(false);
     },

	
	 onOrientationChange: function(oEvent) {
			var bLandscapeOrientation = oEvent.getParameter("landscape"),
				sMsg = "Orientation now is: " + (bLandscapeOrientation ? "Landscape" : "Portrait");
			MessageToast.show(sMsg, {duration: 5000});
		},

		onPressNavToDetail : function(oEvent) {
			this.getSplitAppObj().to(this.createId("detailDetail"));
		},

		onPressDetailBack : function() {
			this.getSplitAppObj().backDetail();
		},

		onPressMasterBack : function() {
			this.getSplitAppObj().backMaster();
		},

		onPressMasterDataMaintain : function() {
			this.getSplitAppObj().toMaster(this.createId("master2"));
		},
		
		onPressViewData: function(){
			this.getSplitAppObj().toMaster(this.createId("master3"));

		},

		onListItemPressMasterData : function(oEvent) {
			var sToPageId = oEvent.getParameter("listItem").getCustomData()[0].getValue();

			this.getSplitAppObj().toDetail(this.createId(sToPageId));
		},
		
		onPressActiveMasterListItem: function(oEvent){
			var sToPageId = oEvent.getSource().getCustomData()[0].getValue()

			this.getSplitAppObj().toDetail(this.createId(sToPageId));
		},

		onPressModeBtn : function(oEvent) {
			var sSplitAppMode = oEvent.getSource().getSelectedButton().getCustomData()[0].getValue();

			this.getSplitAppObj().setMode(sSplitAppMode);
			MessageToast.show("Split Container mode is changed to: " + sSplitAppMode, {duration: 5000});
		},

		getSplitAppObj : function() {
			var result = this.byId("SplitAppDemo");
			if (!result) {
				jQuery.sap.log.info("SplitApp object can't be found");
			}
			return result;
		}

	});

	
});