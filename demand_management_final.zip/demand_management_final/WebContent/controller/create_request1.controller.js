sap.ui.controller("SAP.DemandMgmt.controller.create_request1", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf view.create_request1
*/
    onInit: function () {
        var TextLogModel = new sap.ui.model.json.JSONModel("jsonModel/emailSuggestJson.json");
  this.getView().setModel(TextLogModel, "textLogMdl");
  
  var DateSelectModel = new sap.ui.model.json.JSONModel("jsonModel/dateSelect.json");
  this.getView().setModel(DateSelectModel, "DateSelectModel");
 },

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf demand_management.create_request
*/
//onBeforeRendering: function() {
//
//},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf demand_management.create_request
*/
//onAfterRendering: function() {
//
//},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf demand_management.create_request
*/
//onExit: function() {
//
//}
 
 
 onCRtypeSelChange : function(oEvent){
	 
	 if(oEvent.getParameter("selectedItem").getText() == "Enhancing existing scope" || oEvent.getParameter("selectedItem").getText() == "Discontinue existing scope"){
		 this.getView().byId("crRefId").setVisible(true);
	 }
	 else{
		 this.getView().byId("crRefId").setVisible(false);

	 }
	 
 },
 
	handleSelectionChange: function(oEvent) {
		var changedItem = oEvent.getParameter("changedItem");
		var isSelected = oEvent.getParameter("selected");

		var state = "Selected";
		if (!isSelected) {
			state = "Deselected";
		}

		
	},
	onDateSelectionAdd: function(){
		
		var oComboBoxelectedItem = this.getView().byId("dateMultiComboId").getSelectedKeys();
		var oGridCreate = this.getView().byId("gridId")
		
		for(var i = 0; i<oComboBoxelectedItem.length; i++){
			var sText = oComboBoxelectedItem[i].replace(/_/g ," ")
			
			var oDateVLayout = new sap.ui.layout.VerticalLayout({
			 layoutData: new sap.ui.layout.GridData({span:"L3 M3 S12"}), 
    		 content : [
    			 new sap.m.Label({text : sText + " :"}),
    			 new sap.m.DatePicker({displayFormat : "dd-MMM-YY"})
    		 ]
		})
			oGridCreate.addContent(oDateVLayout);
		}
	},
 
 onPressBack : function(oEvent){
        var router = sap.ui.core.UIComponent.getRouterFor(this);
        router.navTo("LaunchPad",{
               from: "create_request"
               
        });
 },
 OnPressMessage1: function(event){
     var popover = new sap.m.Popover({
            showHeader: false,
    content:[
       new sap.m.Panel({
              content:[
                     new sap.m.VBox({items:[
                                new sap.m.Text({text:"Enter clear purpose for raising DFCR"})
                         ]})
              ]
       })
                  
             
             ] 
      });
     popover.openBy(event.getSource());
},
OnPressMessage2: function(event){
     var popover = new sap.m.Popover({
            showHeader: false,
   content:[
      new sap.m.Panel({
              content:[
                     new sap.m.VBox({items:[
                         new sap.m.Text({text:"Enter transition build to run"})
                 ]})
              ]
       })
           
            ] 
      });
     popover.openBy(event.getSource());
},
OnPressMessage3: function(event){
     var popover = new sap.m.Popover({
            showHeader: false,
   content:[
      new sap.m.Panel({
              content:[
                     new sap.m.VBox({items:[
                         new sap.m.Text({text:"Enter clear deliverables from vendor"})
                         ]})
              ]
      })
           
            ] 
      });
     popover.openBy(event.getSource());
},
OnPressMessage4: function(event){
     var popover = new sap.m.Popover({
            showHeader: false,
   content:[
      new sap.m.Panel({
              content:[
                     new sap.m.VBox({items:[
                         new sap.m.Text({text:"Enter best judged Incident, Service requests, ASA, Project requests, Managed Capacity "})
                         ]})
              ]
      })
           
            ] 
      });
     popover.openBy(event.getSource());
},
OnPressMessage5: function(event){
     var popover = new sap.m.Popover({
            showHeader: false,
   content:[
      new sap.m.Panel({
              content:[
                     new sap.m.VBox({items:[
                          new sap.m.Text({text:"Enter clear milestones from the CR"})
                         ]})
              ]
      })
          
            ] 
      });
     popover.openBy(event.getSource());
},

 OnPressNotify:function(){
        var dialog = new sap.m.Dialog({
          beginButton: new sap.m.Button({
                 text:"Submit to SPM",
                 type:"Accept",
                 press: function(){
                	 var dialogend = new sap.m.Dialog({
                		 type:'Message',
                		 content:[
                			 new sap.m.Text({text:"Change reqquest has been created with id CR123 and a notification has been sent to SPM"})
                		 ],
                		 endButton:new sap.m.Button({text:"OK", press:function (){
                			 dialogend.close();
                			 }
                		 })
                		 
                	 })
                       dialog.close();
                 }
          }),
               content:[
                        new sap.m.Panel({ headerText:"Notify SPM",
                              content:[
                                      
                                                    new sap.ui.layout.form.SimpleForm({
                                                           minWidth:1024,
                                                           maxContainerCols:2,
                                                           editable:true,
                                                           layout:"ResponsiveGridLayout",
                                                           labelSpanL:3,
                                                     labelSpanM:3,
                                                     emptySpanL:4,
                                                     emptySpanM:4,
                                                     columnsL:1,
                                                     columnsM:1,
                                                     content:[
                                                           new sap.m.Label({text:"SAP Email / CUser Id:"}),
                                                           new sap.m.Input({
                                                                            type:"Text",
                                                                            textFormatMode:"ValueKey",
                                                                            placeholder:"Enter ID ...",
                                                                            showSuggestion:true,
                                                                            showValueHelp:false,
                                                                            showTableSuggestionValueHelp : false,
                                                                            suggestionColumns:[
                                                                                   new sap.m.Column({
                                                                                          header:new sap.m.Label({text: "CuserId"})
                                                                                   }),
                                                                                   new sap.m.Column({
                                                                                       header:new sap.m.Label({text: "email"})
                                                                                }),
                                                                            ],
                                                                            suggestionRows:[
                                                                            	new sap.m.ColumnListItem({cells : [new sap.m.Text({text: "C12345"}),
                                                                            		new sap.m.Text({text: "abcd@sap.com"})]}),
                                                                            		
                                                                            		new sap.m.ColumnListItem({cells : [new sap.m.Text({text: "C12346"}),
                                                                                		new sap.m.Text({text: "abcd@sap.com"})]}),
                                                                            ]
                                                           }),
                                                           new sap.m.Label({text:"Key Message"}),
                                                           new sap.m.TextArea({}),
                                                           new sap.m.Label({text:"Negotiation Points"}),
                                                           new sap.m.TextArea({}),
                                                           new sap.m.Label({text:"Preffered Suppliers"}),
                                                           new sap.m.TextArea({}),
                                                     ]
                                                    })
                                             
                                      
                                       ]
                        })
                        ]
        });
        dialog.open();
 },
 


});