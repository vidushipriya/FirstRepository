sap.ui.controller("SAP.DemandMgmt.controller.create_request2", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf controller.create_request2
*/
	onInit: function() {
		/*this.getView().byId("idDateSelect1").setVisible(true);*/
		var DateSelectModel = new sap.ui.model.json.JSONModel("jsonModel/dateSelect.json");
		  this.getView().setModel(DateSelectModel, "DateSelectModel");
		  
		  this.getView().byId("textarea11").setTooltip("Enter clear purpose for raising DFCR");
		  this.getView().byId("textarea12").setTooltip("Enter transition build to run");
		  this.getView().byId("textarea13").setTooltip("Enter clear deliverables from vendor");
		  this.getView().byId("textarea14").setTooltip("Enter best judged Incident, Service requests, ASA, Project requests, Managed Capacity ");
		  this.getView().byId("textarea15").setTooltip("Enter clear milestones from the CR")
	},

/**
 * 
 *
 * 
 * 
 * 
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf controller.create_request2
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf controller.create_request2
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf controller.create_request2
*/
//	onExit: function() {
//
//	}
	
	onCRtypeSelChange : function(oEvent){
		 
		 if(oEvent.getParameter("selectedItem").getText() == "Enhancing existing scope" || oEvent.getParameter("selectedItem").getText() == "Discontinue existing scope"){
			 this.getView().byId("crRefId").setVisible(true);
		 }
		 else{
			 this.getView().byId("crRefId").setVisible(false);

		 }
		 
	 },
	 
	handleSelectionChange: function(oEvent) {
		var changedItem = oEvent.getParameter("changedItem");
		var isSelected = oEvent.getParameter("selected");

		var state = "Selected";
		if (!isSelected) {
			state = "Deselected";
		}

		
	},
	onPressDateAdd: function(oEvent){
		
		if(!this.getView().byId("idDateSelect2").getVisible()){
			this.getView().byId("idDateSelect2").setVisible(true);
			this.getView().byId("iDbuttonRemove").setVisible(true)
			}
		else if(!this.getView().byId("idDateSelect3").getVisible()){
			this.getView().byId("idDateSelect3").setVisible(true);
			oEvent.getSource().setEnabled(false);
			
		}
	},
	
	onPressDateRemove: function(oEvent){
		if(this.getView().byId("idDateSelect3").getVisible()){
			this.getView().byId("idDateSelect3").setVisible(false)
			this.getView().byId("iDbuttonAdd").setEnabled(true)
		}
		else if(this.getView().byId("idDateSelect2").getVisible()){
			this.getView().byId("idDateSelect2").setVisible(false)
			oEvent.getSource().setVisible(false);
		}
	},
	
	onDateSelectionChange: function(oEvent){
		var idSelection = oEvent.getParameter("id").split("--")[1];
		var selectedKey = oEvent.getParameter("selectedItem").getKey();
		var currentItems = oEvent.getSource().getItems();
		var newItems = [];
		for(var i = 0; i<currentItems.length; i++){
			if(currentItems[i].getKey() !== selectedKey){
				newItems.push(currentItems[i])
			}
		}
		var copyNewItems = [];
		for(var i = 0; i<newItems.length;i++){
			var oItem = new sap.ui.core.Item({text : newItems[i].getText(), key :  newItems[i].getKey() })
			copyNewItems.push(oItem);
		}
		var nextItem = Number(oEvent.getParameter("id").split("--")[1].slice(-1)) + 1;
		if(nextItem <= 3){
			var nextItemId = "idDateSelect0" + nextItem;
			this.getView().byId(nextItemId).removeAllItems();
			for(var i=0; i<copyNewItems.length;i++){
				this.getView().byId(nextItemId).addItem(copyNewItems[i])
			}
		
	}
		
	},

	
	 onPressBack : function(oEvent){
	        var router = sap.ui.core.UIComponent.getRouterFor(this);
	        router.navTo("LaunchPad",{
	               from: "create_request"
	               
	        });
	 },
	 
	 _popOverReturnFun : function(sMsg){
		 var oPopOver = new sap.m.Popover({
	            showHeader: false,
	    	    content:[
	    	       new sap.m.Panel({
	    	              content:[
	    	                     new sap.m.VBox({items:[
	    	                                new sap.m.Text({text:sMsg})
	    	                         ]})
	    	              ]
	    	       })
	    	                  
	    	             
	    	             ] 
	    	      });
		 return oPopOver
	 },
		onDateSelectionAdd: function(){
			
			var oComboBoxelectedItem = this.getView().byId("dateMultiComboId").getSelectedKeys();
			var oGridCreate = this.getView().byId("gridId")
			
			for(var i = 0; i<oComboBoxelectedItem.length; i++){
				var sText = oComboBoxelectedItem[i].replace(/_/g ," ")
				
				var oDateVLayout = new sap.ui.layout.VerticalLayout({
				 layoutData: new sap.ui.layout.GridData({span:"L3 M3 S12"}), 
	    		 content : [
	    			 new sap.m.Label({text : sText + " :"}),
	    			 new sap.m.DatePicker({displayFormat : "dd-MMM-YY"})
	    		 ]
			})
				oGridCreate.addContent(oDateVLayout);
			}
		},
	 
	 OnPressMessage1: function(event){
		
	     var popover =  this._popOverReturnFun("Enter clear purpose for raising DFCR");
	     popover.openBy(event.getSource());
	},
	OnPressMessage2: function(event){
	     var popover = this._popOverReturnFun("Enter transition build to run");
	     popover.openBy(event.getSource());
	},
	OnPressMessage3: function(event){
		 var popover = this._popOverReturnFun("Enter clear deliverables from vendor");
	     popover.openBy(event.getSource());
	},
	OnPressMessage4: function(event){
		 var popover = this._popOverReturnFun("Enter best judged Incident, Service requests, ASA, Project requests, Managed Capacity ");
	     popover.openBy(event.getSource());
	},
	OnPressMessage5: function(event){
		 var popover = this._popOverReturnFun("Enter clear milestones from the CR");
	     popover.openBy(event.getSource());
	},

	 OnPressNotify:function(){       var oDialog = new sap.m.Dialog({
         showHeader: false,
         subHeader:
               new sap.m.Toolbar({content : [
                      new sap.m.ToolbarSpacer(),
                      new sap.m.Text({text: "Submit"}),
                      new sap.m.ToolbarSpacer(),
                      new sap.m.Button({
                             
                              icon: "sap-icon://decline",
                             press: function(){
                                   oDialog.close();
                                   oDialog.destroy();
                             }
                      })
               ]}),
//               endButton: new sap.m.Button({text: "OK", press: function(){
//                      if(sap.ui.getCore().byId("checkBoxId").getSelected()== true){
//                            sap.ui.getCore().byId("hboxid").setVisible(true);
//                            this.setVisible(false);
//                           sap.ui.getCore().byId("beginbuttonid").setVisible(true);
//                           sap.ui.getCore().byId("checkBoxId").setVisible(false)
//                      }else{
//                            oDialog.close();
//                            oDialog.destroy();
//                      }
//                    
//               }}),
               
               beginButton: new sap.m.Button("beginbuttonid",{text:"Send", press:function(){
                      oDialog.close();
                            oDialog.destroy();
               }}).addStyleClass("Footerbutton"),
               content : [
                      new sap.m.VBox("vboxid111",{
                            items:[
                                   new sap.m.Text({text:"CR12345 created successfully"}),
                                   new sap.m.CheckBox("checkBoxId",{text:"Do you want to notify SPM or Vendor?" , select: function(){
                                	   if(sap.ui.getCore().byId("checkBoxId").getSelected()== true){
                                           sap.ui.getCore().byId("hboxid").setVisible(true);
                                           this.setVisible(false);
                                          sap.ui.getCore().byId("beginbuttonid").setVisible(true);
                                          sap.ui.getCore().byId("checkBoxId").setVisible(false)
                                     }
                                	   else{
                                		   sap.ui.getCore().byId("hboxid").setVisible(false);
                                           this.setVisible(true);
                                          sap.ui.getCore().byId("beginbuttonid").setVisible(false);
                                          sap.ui.getCore().byId("checkBoxId").setVisible(true)
                                	   }
                                   }})
                            ]
                      }),
                      new sap.m.HBox("hboxid",{
                            items:[
                                   new sap.m.CheckBox("cbspm",{text: "Do you want to notify SPM?",
                                          select :function(){
                                          if(sap.ui.getCore().byId("cbspm").getSelected() == true){
                                                 sap.ui.getCore().byId("hboxid2").setVisible(true),
                                                 sap.ui.getCore().byId("vboxid21").setVisible(true)
                                          }else{
                                                 sap.ui.getCore().byId("vboxid21").setVisible(false)
                                          }
                                   }}),
                                   new sap.m.CheckBox("cbvendor",{text: "Do you want to assign it to Vendor?",
                                          select :function(){
                                          if(sap.ui.getCore().byId("cbvendor").getSelected() == true){
                                                 sap.ui.getCore().byId("hboxid2").setVisible(true),
                                                 sap.ui.getCore().byId("vboxid22").setVisible(true)
                                          }else{
                                                 sap.ui.getCore().byId("vboxid22").setVisible(false)
                                          }
                                   }
                                   })
                            ]
                      }),
                      new sap.m.HBox("hboxid2",{
                            items:[
                                   new sap.m.VBox("vboxid21",{
                                          items:[

                                   new sap.m.Label({text:"SAP Email Address : "}),
                                   new sap.m.Input({width:"93%", value:"John_Miller@sap.com", enabled:false
                                                    /*type:"Text",
                                                    textFormatMode:"ValueKey",
                                                   
                                                    showSuggestion:true,
                                                    showValueHelp:false,
                                                    showTableSuggestionValueHelp : false,
                                                    suggestionColumns:[
                                                           new sap.m.Column({
                                                                  header:new sap.m.Label({text: "CuserId"})
                                                           }),
                                                           new sap.m.Column({
                                                               header:new sap.m.Label({text: "email"})
                                                        }),
                                                    ],
                                                    suggestionRows:[
                                                           new sap.m.ColumnListItem({cells : [new sap.m.Text({text: "C12345"}),
                                                                 new sap.m.Text({text: "abcd@sap.com"})]}),
                                                                 
                                                                 new sap.m.ColumnListItem({cells : [new sap.m.Text({text: "C12346"}),
                                                                 new sap.m.Text({text: "abcd@sap.com"})]}),
                                                    ]*/
                                   }),
                                   new sap.m.Label({text:"Remarks : "}),
                                  /* new sap.m.TextArea({}),
                                   new sap.m.Label({text:"Negotiation Points : "}),
                                   new sap.m.TextArea({}),
                                   new sap.m.Label({text:"Preferred Suppliers : "}),*/
                                   new sap.m.TextArea({})
                                          ]
                                   }),
                                   new sap.m.VBox("vboxid22",{
                                          items:[
                                        	  	   new sap.m.Label({text:"Select Vendor :"}),
                                        	  	   new sap.m.ComboBox({width:"81%", items:[new sap.ui.core.Item({text: "vendor 1", key: "All"}),
												          new sap.ui.core.Item({text: "vendor 5", key: "New", enabled:false}),
													         new sap.ui.core.Item({text: "vendor 2", key: "Completed"}),
													         new sap.ui.core.Item({text: "vendor 3", key: "WIP" ,enabled:false})
													                    ]}),
                                                   new sap.m.Label({text:"Vendor Email Address :"}),
				                                   new sap.m.Input({width:"81%",}),
				                                   new sap.m.Label({text:"Remarks :"}),
				                                   new sap.m.TextArea({}),
				                                   /*new sap.m.Label({text:"Comments :"}),
				                                   new sap.m.TextArea({}),*/
                                          ]
                                   })
                            ]
                      }),
                      
                      
                      
                      
                      
                      /*
                            
                      new sap.m.CheckBox({text: "Do you want to notify SPM", select : function(oEvent){
                       var bGetSelected1 = oEvent.getParameter("selected");
                       var bGetSelected2 =oEvent.getSource().getParent().getContent()[1].getProperty("selected");
                       
                       if(bGetSelected1 && bGetSelected2){
                             oEvent.getSource().getParent().getContent()[2].setVisible(true);
                              oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[0].setVisible(true)
                              oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[1].setVisible(true)
                             oDialog.getEndButton().setText("Send");
                       }
                       else if(bGetSelected1 && !bGetSelected2){
                             oEvent.getSource().getParent().getContent()[2].setVisible(true);
                              oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[0].setVisible(true)
                              oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[1].setVisible(false)
                             oDialog.getEndButton().setText("Send");
                       }
                       
                       else if(!bGetSelected1 && bGetSelected2){
                             oEvent.getSource().getParent().getContent()[2].setVisible(true);
                              oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[0].setVisible(false)
                              oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[1].setVisible(true)
                             oDialog.getEndButton().setText("Send");
                       }
                       else{
                             oEvent.getSource().getParent().getContent()[2].setVisible(false);
                              oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[0].setVisible(false)
                              oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[1].setVisible(false)
                             oDialog.getEndButton().setText("Ok");
                       }
                       
                       
                      }}),
                     
                      new sap.m.CheckBox({text: "Do you want to assign it to Vendor", select : function(oEvent){
                       var bGetSelected2 = oEvent.getParameter("selected");
                       var bGetSelected1 =oEvent.getSource().getParent().getContent()[0].getProperty("selected");
                       
                       if(bGetSelected1 && bGetSelected2){
                             oEvent.getSource().getParent().getContent()[2].setVisible(true);
                              oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[0].setVisible(true)
                              oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[1].setVisible(true)
                             oDialog.getEndButton().setText("Send");
                       }
                       else if(bGetSelected1 && !bGetSelected2){
                             oEvent.getSource().getParent().getContent()[2].setVisible(true);
                              oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[0].setVisible(true)
                              oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[1].setVisible(false)
                             oDialog.getEndButton().setText("Send");
                       }
                       
                       else if(!bGetSelected1 && bGetSelected2){
                             oEvent.getSource().getParent().getContent()[2].setVisible(true);
                              oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[0].setVisible(false)
                              oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[1].setVisible(true)
                             oDialog.getEndButton().setText("Send");
                       }
                       else{
                             oEvent.getSource().getParent().getContent()[2].setVisible(false);
                              oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[0].setVisible(false)
                              oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[1].setVisible(false)
                             oDialog.getEndButton().setText("Ok");
                       }
                       
                      }}),
                     
                      new sap.m.Panel({ visible: false,
                         content:[
//                           new sap.ui.layout.Grid({content : []}) 
                              new sap.ui.layout.HorizontalLayout({
                                     layoutData: new sap.ui.layout.GridData({span:"L6 M6 S12"}), 
                                     content : [
                                     
                                     new sap.ui.layout.form.SimpleForm({
                                 minWidth:1024,
                                 maxContainerCols:2,
                                 editable:true,
                                 layout:"ResponsiveGridLayout",
                                 labelSpanL:3,
                           labelSpanM:3,
                           emptySpanL:4,
                           emptySpanM:4,
                           columnsL:1,
                           columnsM:1,
                           content:[
                                 new sap.m.Label({text:"SAP Email Address"}),
                                 new sap.m.Input({
                                                  type:"Text",
                                                  textFormatMode:"ValueKey",
                                                  placeholder:"Enter ID ...",
                                                  showSuggestion:true,
                                                  showValueHelp:false,
                                                  showTableSuggestionValueHelp : false,
                                                  suggestionColumns:[
                                                         new sap.m.Column({
                                                                header:new sap.m.Label({text: "CuserId"})
                                                         }),
                                                         new sap.m.Column({
                                                             header:new sap.m.Label({text: "email"})
                                                      }),
                                                  ],
                                                  suggestionRows:[
                                                         new sap.m.ColumnListItem({cells : [new sap.m.Text({text: "C12345"}),
                                                               new sap.m.Text({text: "abcd@sap.com"})]}),
                                                               
                                                               new sap.m.ColumnListItem({cells : [new sap.m.Text({text: "C12346"}),
                                                               new sap.m.Text({text: "abcd@sap.com"})]}),
                                                  ]
                                 }),
                                 new sap.m.Label({text:"Key Message"}),
                                 new sap.m.TextArea({}),
                                 new sap.m.Label({text:"Negotiation Points"}),
                                 new sap.m.TextArea({}),
                                 new sap.m.Label({text:"Preferred Suppliers"}),
                                 new sap.m.TextArea({}),
                           ]
                          }),
                                     new sap.ui.layout.form.SimpleForm({
                                    minWidth:1024,
                                    maxContainerCols:2,
                                    editable:true,
                                    layout:"ResponsiveGridLayout",
                                    labelSpanL:3,
                              labelSpanM:3,
                              emptySpanL:4,
                              emptySpanM:4,
                              columnsL:1,
                              columnsM:1,
                              content:[
                                    new sap.m.Label({text:"Vendor Email Address :"}),
                                    new sap.m.Input({}),
                                    new sap.m.Label({text:"Key Message :"}),
                                    new sap.m.TextArea({}),
                                    new sap.m.Label({text:"Comments :"}),
                                    new sap.m.TextArea({}),
                                    
                              ]
                             })   
                                     
                              ]}),
                                 
                                           
                                        
                                 
                                  ]
                   })
                     
                */],
          beforeOpen: function(){
              sap.ui.getCore().byId("hboxid").setVisible(false);
              sap.ui.getCore().byId("hboxid2").setVisible(false);
              sap.ui.getCore().byId("vboxid21").setVisible(false);
              sap.ui.getCore().byId("vboxid22").setVisible(false);
              sap.ui.getCore().byId("beginbuttonid").setVisible(false)
      if(sap.ui.Device.system.phone){
            
            this.setStretch(true);
      }else{
            this.setStretch(false);
      }
},
afterOpen: function(){
this.focus();
},
  });
oDialog.open();

},
	 
OnPressSaveDraft : function(){
	var dialog = new sap.m.Dialog({
		title: 'Success',
		type: 'Message',
		state: 'Success',
		content: new sap.m.Text({
			text: 'CR12345 saved successfully'
		}),
		beginButton: new sap.m.Button({
			text: 'OK',
			press: function () {
				dialog.close();
			}
		}),
		afterClose: function() {
			dialog.destroy();
		}
	});

	dialog.open();
},
	
	
});