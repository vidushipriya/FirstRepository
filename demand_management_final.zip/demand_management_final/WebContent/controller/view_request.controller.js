
sap.ui.define([
		'jquery.sap.global',
		'sap/m/MessageToast',
		'./Formatter',
		'sap/ui/core/mvc/Controller',
		'sap/ui/model/json/JSONModel'
	], function(jQuery, MessageToast, Formatter, Controller, JSONModel) {
	"use strict";
 
	var PageController = Controller.extend("SAP.DemandMgmt.controller.view_request", {

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf demand_management.view_request1
*/
	onInit: function() {
		var viewReqModel = new sap.ui.model.json.JSONModel("jsonModel/viewRequest.json");
        this.getView().setModel(viewReqModel, "viewReqModel");
        
        var TextLogModel = new sap.ui.model.json.JSONModel("jsonModel/data.json");
        this.getView().setModel(TextLogModel, "textLogMdl");
	},
	
	
	filterDetailPageOpened : function(oEvent){
		debugger
	},
/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf demand_management.view_request1
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf demand_management.view_request1
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf demand_management.view_request1
*/
//	onExit: function() {
//
//	}
	
	updateMasterListFinished: function(oEvent){
		
		 var firstItem = this.getView().byId("ListId").getItems()[0];   
	     this.getView().byId("ListId").setSelectedItem(firstItem,true);
	     var contexts =  this.getView().byId("ListId").getSelectedContexts();
	     var items = contexts.map(function (c) {
				return c.getObject();
			});
	     
	     var oDetailPage = this.getView().byId("iddetail");
	     /*oDetailPage.setTitle(items[0].crNum);*/
	     var spmPanel = this.getView().byId("spnDetailsPanelId")
	     var vendorPanel = this.getView().byId("vendorDetailsPanelId")
	     
	     if(items[0].crStatus === "Drafts"){
	    	 spmPanel.setVisible(false);
	    	 vendorPanel.setVisible(false)
	     }
	     else if(items[0].crStatus === "Released by SPM"){
	    	 vendorPanel.setVisible(true)
	    	 spmPanel.setVisible(true);
	     }
	     else{
	    	 vendorPanel.setVisible(false)
	    	 spmPanel.setVisible(true); 
	     }
	},
	
	onListItemPress : function(oEvent){
		var otable = this.getView().byId("ListId");
		var contexts = otable.getSelectedContexts();
		
		var items = contexts.map(function (c) {
			return c.getObject();
		});
		
		var oDetailPage = this.getView().byId("iddetail");
	     oDetailPage.setTitle(items[0].crNum);
	     
	     var spmPanel = this.getView().byId("spnDetailsPanelId")
	     var vendorPanel = this.getView().byId("vendorDetailsPanelId")
	     
	     if(items[0].crStatus === "Drafts"){
	    	 spmPanel.setVisible(false);
	    	 vendorPanel.setVisible(false)
	     }
	     else if(items[0].crStatus === "Released by SPM"){
	    	 vendorPanel.setVisible(true)
	    	 spmPanel.setVisible(true);
	     }
	     else{
	    	 vendorPanel.setVisible(false)
	    	 spmPanel.setVisible(true); 
	     }
	},
	
	handleViewSettingsDialogButtonPressed : function(oEvent){
		if (!this._oDialog) {
			this._oDialog = sap.ui.xmlfragment("SAP.DemandMgmt.view.tableSettingDialog", this);
		}
		this._oDialog.setModel(this.getView().getModel("viewReqModel"), "viewReqModel")
		
		// toggle compact style
		jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);
		this._oDialog.open();
		
	},
	
	handleViewSettingsDialogButtonPressedd : function(){
		if (!this._oDialogs) {
			this._oDialogs = sap.ui.xmlfragment("SAP.DemandMgmt.view.tableSettingDialog2", this);
		}
		this._oDialogs.setModel(this.getView().getModel("viewReqModel"), "viewReqModel")
		
		// toggle compact style
		jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialogs);
		this._oDialogs.open();
		
	},
	

	onPressBack : function(oEvent){
		var router = sap.ui.core.UIComponent.getRouterFor(this);
		router.navTo("LaunchPad",{
			from: "view_request1"
			
		});
	},
	
	onPressEdit : function(oEvent){
		var oControlId = ["idPropkaustId","ktdateview","ktenddateview","golivedateview", "idPropContactNum", "idPropDept","crTypeId","addbtnid1","dateMultiComboIdz", "idPurpose", "idTransition", "idExpectation", "idVolume", "idMilestone","idUploader", "idCategory", "idInvolvedSys","idRemarks"]
		for(var i=0; i<oControlId.length;i++){
			this.getView().byId(oControlId[i]).setEnabled(true);
		}
		
		this.getView().byId("idEditButton").setVisible(false);
		this.getView().byId("idCommentButton").setVisible(false);
		this.getView().byId("idSubmitButton").setVisible(true);
		
	},
	onPressDownload : function(oEvent){
        if (!this._oDialogDownload) {
               this._oDialogDownload = sap.ui.xmlfragment("SAP.DemandMgmt.view.downloadTable", this);
        }

        // Multi-select if required
        var bMultiSelect = !!oEvent.getSource().data("multi");
        this._oDialogDownload.setMultiSelect(bMultiSelect);
        
        this._oDialogDownload.setModel(this.getView().getModel("viewReqModel"), "viewReqModel")

        this.getView().addDependent(this._oDialogDownload);

        // toggle compact style
        jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialogDownload);
        this._oDialogDownload.open();
 },

	
	onPressSubmit : function(oEvent){		var oControlId = ["idPropkaustId","ktenddateview", "golivedateview","ktdateview", "idPropContactNum", "idPropDept","crTypeId","addbtnid1","dateMultiComboIdz", "idPurpose", "idTransition", "idExpectation", "idVolume", "idMilestone","idUploader", "idCategory", "idInvolvedSys","idRemarks"]

    for(var i=0; i<oControlId.length;i++){
        this.getView().byId(oControlId[i]).setEnabled(false);
}
 this.getView().byId("idEditButton").setVisible(true);
 this.getView().byId("idCommentButton").setVisible(true);
 this.getView().byId("idSubmitButton").setVisible(false);
 
/* var otable = this.getView().byId("ListId");
var contexts = otable.getSelectedContexts();

var items = contexts.map(function (c) {
  return c.getObject();
});

items[0].crStatus;*/
 var items ="Drafts";
var oDialog = new sap.m.Dialog({
  showHeader: false,
  subHeader:
        new sap.m.Toolbar({content : [
               new sap.m.ToolbarSpacer(),
               new sap.m.Text({text: "Submit"}),
               new sap.m.ToolbarSpacer(),
               new sap.m.Button({
                      
                       icon: "sap-icon://decline",
                      press: function(){
                            oDialog.close();
                            oDialog.destroy();
                      }
               })
        ]}),
//        endButton: new sap.m.Button({text: "OK", press: function(){
//            if(sap.ui.getCore().byId("checkBoxId").getSelected()== true){
//                sap.ui.getCore().byId("hboxid").setVisible(true);
//                this.setVisible(false);
//               sap.ui.getCore().byId("beginbuttonid").setVisible(true);
//               sap.ui.getCore().byId("checkBoxId").setVisible(false)
//          }else{
//                oDialog.close();
//                oDialog.destroy();
//          }
//        
//   }}),
   beginButton: new sap.m.Button("beginbuttonid",{text:"Send",visible: false, press:function(){
       oDialog.close();
             oDialog.destroy();
}}).addStyleClass("Footerbutton"),
        content : [
        new sap.m.VBox({
               items:[
                      new sap.m.Text({text:"CR-120 saved successfully "}),
                      new sap.m.CheckBox("checkBoxId",{text:"Do you want to notify SPM or Vendor?", select: function(){
                    	  if(sap.ui.getCore().byId("checkBoxId").getSelected()== true){
                              sap.ui.getCore().byId("hboxid").setVisible(true);
                              this.setVisible(false);
                             sap.ui.getCore().byId("beginbuttonid").setVisible(true);
                             sap.ui.getCore().byId("checkBoxId").setVisible(false)
                        }else{
                        	 sap.ui.getCore().byId("hboxid").setVisible(false);
                             this.setVisible(true);
                            sap.ui.getCore().byId("beginbuttonid").setVisible(false);
                            sap.ui.getCore().byId("checkBoxId").setVisible(true)
                        }
                      }})
               ]
        }),
        new sap.m.HBox("hboxid",{
               items:[
                      new sap.m.CheckBox("cbspm",{text: "Do you want to notify SPM?",
                             select :function(){
                                    if(sap.ui.getCore().byId("cbspm").getSelected() == true){
                                           sap.ui.getCore().byId("hboxid2").setVisible(true),
                                           sap.ui.getCore().byId("vboxid21").setVisible(true)
                                    }else{
                                           sap.ui.getCore().byId("vboxid21").setVisible(false)
                                    }
                             }}),
                      new sap.m.CheckBox("cbvendor",{text: "Do you want to assign it to Vendor?",
                             select :function(){
                             if(sap.ui.getCore().byId("cbvendor").getSelected() == true){
                                    sap.ui.getCore().byId("hboxid2").setVisible(true),
                                    sap.ui.getCore().byId("vboxid22").setVisible(true)
                             }else{
                                    sap.ui.getCore().byId("vboxid22").setVisible(false)
                             }
                      }
                      })
               ]
        }),
        new sap.m.HBox("hboxid2",{
               items:[
                      new sap.m.VBox("vboxid21",{
                             items:[

                            new sap.m.Label({text:"SAP Email Address : "}),
                            new sap.m.Input({width:"93%",
                                             type:"Text",
                                             textFormatMode:"ValueKey",
                                             placeholder:"",
                                             showSuggestion:true,
                                             showValueHelp:false,
                                             showTableSuggestionValueHelp : false,
                                             suggestionColumns:[
                                                    new sap.m.Column({
                                                           header:new sap.m.Label({text: "CuserId"})
                                                    }),
                                                    new sap.m.Column({
                                                        header:new sap.m.Label({text: "email"})
                                                 }),
                                             ],
                                             suggestionRows:[
                                                    new sap.m.ColumnListItem({cells : [new sap.m.Text({text: "C12345"}),
                                                          new sap.m.Text({text: "abcd@sap.com"})]}),
                                                          
                                                          new sap.m.ColumnListItem({cells : [new sap.m.Text({text: "C12346"}),
                                                          new sap.m.Text({text: "abcd@sap.com"})]}),
                                             ]
                            }),
                            new sap.m.Label({text:"Key Message : "}),
                           new sap.m.TextArea({}),
                            new sap.m.Label({text:"Negotiation Points : "}),
                            new sap.m.TextArea({}),
                            new sap.m.Label({text:"Preferred Suppliers : "}),
                            new sap.m.TextArea({})
                             ]
                      }),
                      new sap.m.VBox("vboxid22",{
                             items:[
                            	 new sap.m.Label({text:"Select Vendor :"}),
                            	 new sap.m.Input({width:"93%"}),
                                 new sap.m.Label({text:"Vendor Email Address :"}),
	                            new sap.m.Input({width:"93%"}),
	                            new sap.m.Label({text:"Key Message :"}),
	                            new sap.m.TextArea({}),
	                            new sap.m.Label({text:"Comments :"}),
	                            new sap.m.TextArea({}),
                             ]
                      })
               ]
        }),
        
         
         
         
         
         /*
              
               new sap.m.CheckBox({text: "Do you want to notify SPM", select : function(oEvent){
                var bGetSelected1 = oEvent.getParameter("selected");
                var bGetSelected2 =oEvent.getSource().getParent().getContent()[1].getProperty("selected");
                
                if(bGetSelected1 && bGetSelected2){
                      oEvent.getSource().getParent().getContent()[2].setVisible(true);
                       oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[0].setVisible(true)
                       oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[1].setVisible(true)
                      oDialog.getEndButton().setText("Send");
                }
                else if(bGetSelected1 && !bGetSelected2){
                      oEvent.getSource().getParent().getContent()[2].setVisible(true);
                       oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[0].setVisible(true)
                       oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[1].setVisible(false)
                      oDialog.getEndButton().setText("Send");
                }
                
                else if(!bGetSelected1 && bGetSelected2){
                      oEvent.getSource().getParent().getContent()[2].setVisible(true);
                       oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[0].setVisible(false)
                       oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[1].setVisible(true)
                      oDialog.getEndButton().setText("Send");
                }
                else{
                      oEvent.getSource().getParent().getContent()[2].setVisible(false);
                       oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[0].setVisible(false)
                       oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[1].setVisible(false)
                      oDialog.getEndButton().setText("Ok");
                }
                
                
               }}),
              
               new sap.m.CheckBox({text: "Do you want to assign it to Vendor", select : function(oEvent){
                var bGetSelected2 = oEvent.getParameter("selected");
                var bGetSelected1 =oEvent.getSource().getParent().getContent()[0].getProperty("selected");
                
                if(bGetSelected1 && bGetSelected2){
                      oEvent.getSource().getParent().getContent()[2].setVisible(true);
                       oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[0].setVisible(true)
                       oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[1].setVisible(true)
                      oDialog.getEndButton().setText("Send");
                }
                else if(bGetSelected1 && !bGetSelected2){
                      oEvent.getSource().getParent().getContent()[2].setVisible(true);
                       oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[0].setVisible(true)
                       oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[1].setVisible(false)
                      oDialog.getEndButton().setText("Send");
                }
                
                else if(!bGetSelected1 && bGetSelected2){
                      oEvent.getSource().getParent().getContent()[2].setVisible(true);
                       oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[0].setVisible(false)
                       oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[1].setVisible(true)
                      oDialog.getEndButton().setText("Send");
                }
                else{
                      oEvent.getSource().getParent().getContent()[2].setVisible(false);
                       oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[0].setVisible(false)
                       oEvent.getSource().getParent().getContent()[2].getContent()[0].getContent()[1].setVisible(false)
                      oDialog.getEndButton().setText("Ok");
                }
                
               }}),
              
               new sap.m.Panel({ visible: false,
                  content:[
//                    new sap.ui.layout.Grid({content : []}) 
                       new sap.ui.layout.HorizontalLayout({
                              layoutData: new sap.ui.layout.GridData({span:"L6 M6 S12"}), 
                              content : [
                              
                              new sap.ui.layout.form.SimpleForm({
                          minWidth:1024,
                          maxContainerCols:2,
                          editable:true,
                          layout:"ResponsiveGridLayout",
                          labelSpanL:3,
                    labelSpanM:3,
                    emptySpanL:4,
                    emptySpanM:4,
                    columnsL:1,
                    columnsM:1,
                    content:[
                          new sap.m.Label({text:"SAP Email Address"}),
                          new sap.m.Input({
                                           type:"Text",
                                           textFormatMode:"ValueKey",
                                           placeholder:"Enter ID ...",
                                           showSuggestion:true,
                                           showValueHelp:false,
                                           showTableSuggestionValueHelp : false,
                                           suggestionColumns:[
                                                  new sap.m.Column({
                                                         header:new sap.m.Label({text: "CuserId"})
                                                  }),
                                                  new sap.m.Column({
                                                      header:new sap.m.Label({text: "email"})
                                               }),
                                           ],
                                           suggestionRows:[
                                                  new sap.m.ColumnListItem({cells : [new sap.m.Text({text: "C12345"}),
                                                        new sap.m.Text({text: "abcd@sap.com"})]}),
                                                        
                                                        new sap.m.ColumnListItem({cells : [new sap.m.Text({text: "C12346"}),
                                                        new sap.m.Text({text: "abcd@sap.com"})]}),
                                           ]
                          }),
                          new sap.m.Label({text:"Key Message"}),
                          new sap.m.TextArea({}),
                          new sap.m.Label({text:"Negotiation Points"}),
                          new sap.m.TextArea({}),
                          new sap.m.Label({text:"Preferred Suppliers"}),
                          new sap.m.TextArea({}),
                    ]
                   }),
                              new sap.ui.layout.form.SimpleForm({
                             minWidth:1024,
                             maxContainerCols:2,
                             editable:true,
                             layout:"ResponsiveGridLayout",
                             labelSpanL:3,
                       labelSpanM:3,
                       emptySpanL:4,
                       emptySpanM:4,
                       columnsL:1,
                       columnsM:1,
                       content:[
                             new sap.m.Label({text:"Vendor Email Address :"}),
                             new sap.m.Input({}),
                             new sap.m.Label({text:"Key Message :"}),
                             new sap.m.TextArea({}),
                             new sap.m.Label({text:"Comments :"}),
                             new sap.m.TextArea({}),
                             
                       ]
                      })   
                              
                       ]}),
                          
                                    
                                 
                          
                           ]
            })
              
         */],
   beforeOpen: function(){
        sap.ui.getCore().byId("hboxid").setVisible(false);
        sap.ui.getCore().byId("hboxid2").setVisible(false);
        sap.ui.getCore().byId("vboxid21").setVisible(false);
        sap.ui.getCore().byId("vboxid22").setVisible(false);
if(sap.ui.Device.system.phone){
     
     this.setStretch(true);
}else{
     this.setStretch(false);
}
},
afterOpen: function(){
this.focus();
},
})

/* if(items == "Drafts"){
  oDialog.getContent()[0].setVisible(true);
  oDialog.getContent()[1].setVisible(true);
  oDialog.getContent()[2].setVisible(false);
}
else if(items == "New"){
  oDialog.getContent()[0].setVisible(true);
  oDialog.getContent()[1].setVisible(true);
  oDialog.getContent()[2].setVisible(false);
}
else {
  oDialog.getContent()[0].setVisible(false);
  oDialog.getContent()[1].setVisible(true);
  oDialog.getContent()[2].setVisible(false);
}*/

oDialog.open();
},
	
	onPressComment : function(oEvent){
		
		var dialogCreate =new sap.m.Dialog({
            type: 'Message',
            showHeader:false,
            contentWidth:'40%',
            subHeader:[],
            content:[
            	
//            	new sap.ui.layout.HorizontalLayout({content : [
//            		new sap.m.Label({text : "To"}),
//                	new sap.m.Input({})
//            	]}),
            	new sap.m.Label({text : "To"}),
            	new sap.m.Input({}),
            	
            	new sap.m.FeedInput({showIcon: true, post : function(){
            		dialogCreate.close();
            	}}),
            	
            new sap.m.List({
            	items: {
            		path: 'textLogMdl>/EntryCollection',
            		template: new sap.m.FeedListItem({
            		info : "Wrote on {textLogMdl>Date}",
					timestamp : "{textLogMdl>RQNo} {textLogMdl>Author} / {textLogMdl>Place}",
					text : "{textLogMdl>Text}",
					convertLinksToAnchorTags: "All"
            		})
            	}}),
            	
            ],
            
            endButton : new sap.m.Button({text: "Close", press : function(){
            	dialogCreate.close();
            }}),
            beforeOpen: function(){
                                    if(sap.ui.Device.system.phone){
                                          
                                          this.setStretch(true);
                                    }else{
                                          this.setStretch(false);
                                    }
                        },
         afterOpen: function(){
                        this.focus();
                           },
         escapeHandler : function(){
        	 
        	 var escHandleDialog = new sap.m.Dialog({
        		 content: [new sap.m.Text({text: "Your all data will be lost"})],
//        		 subHeader: new sap.m.Text({text:"info"}),
        		 beginButton : new sap.m.Button({text:"ok", press : function(){
        			 escHandleDialog.close();
        			 dialogCreate.close();
        			 
        		 }}),
        		 endButton: new sap.m.Button({text:"close", press : function(){
        			 escHandleDialog.close();

        		 }})
        	 })
        	 escHandleDialog.open();
        	 
         }
})
		
		dialogCreate.setModel(this.getView().getModel("textLogMdl"), "textLogMdl")
		dialogCreate.open();
		
	},
	
	
	})
});